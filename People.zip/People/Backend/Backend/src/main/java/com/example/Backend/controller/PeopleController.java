package com.example.Backend.controller;

import com.example.Backend.model.Person;
import com.example.Backend.repository.PersonRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/people")
@CrossOrigin(origins = "*")
public class PeopleController {
    private final PersonRepository repo;

    public PeopleController(PersonRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Person> getAll() {
        return repo.findAll().reversed(); // mostra do mais recente pro mais antigo
    }

    @PostMapping
    public Person create(@RequestBody Person person) {
        if (person.getName() == null || person.getName().isEmpty()) {
            throw new IllegalArgumentException("name é obrigatório");
        }
        if (person.getAge() < 0) {
            throw new IllegalArgumentException("age precisa ser >= 0");
        }
        return repo.save(person);
    }
}
